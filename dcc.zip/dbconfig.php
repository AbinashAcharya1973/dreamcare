﻿<?php
	$hostname = "localhost";
	$username = "root";
	$pwd = "pass09876";	
	$databasename='dcs';
?>
