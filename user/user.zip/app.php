<?php
$rtpath="index";
?>