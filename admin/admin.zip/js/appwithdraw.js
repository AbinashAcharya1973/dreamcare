var AppWithdraw = {
  data: {
    closingbalance: 0.0,
    withdrawalamount: 0.0,
    appslno: "",
  },

  mounted: function () {},
  methods: {
    approve: function () {
      this.withdrawalamount = document.getElementById("amount").value;
      this.appslno = document.getElementById("slno").value;

      axios
        .post("appwithdraw.php", { amt: this.withdrawalamount,id:this.appslno })
        .then(function (response) {
          alert(response.data); 
          window.location.href = 'withdrawreq.php';         
        })
        .catch(function (error) {
          alert(error);
        });
    },
  },
};
